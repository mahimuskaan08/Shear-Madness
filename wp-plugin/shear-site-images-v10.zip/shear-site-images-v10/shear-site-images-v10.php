<?php
/**
 * Plugin Name: Shear Site Images 10
 * Plugin URI:  https://shearmadnesshoboken.com
 * Description: Manage site images for Shear Madness Hoboken via a dedicated admin page and REST API.
 * Version:     10.0.1
 * Author:      Shear Madness Hoboken
 * License:     GPL-2.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Raise PHP upload/memory limits as early as possible so WP media uploads succeed.
@ini_set( 'upload_max_filesize', '64M' );
@ini_set( 'post_max_size',       '64M' );
@ini_set( 'memory_limit',        '256M' );
@ini_set( 'max_execution_time',  '300' );

// Also raise the limit WordPress itself reports to the media uploader.
add_filter( 'upload_size_limit', function () {
    return 64 * 1024 * 1024; // 64 MB
} );

define( 'SSI10_OPTION_KEY',   'shear_site_images' );
define( 'SSI10_REST_NS',      'shear/v1' );
define( 'SSI10_REST_ROUTE',   'site-images' );
define( 'SSI10_NONCE_ACTION', 'ssi10_save' );
define( 'SSI10_NONCE_NAME',   'ssi10_nonce' );

// ── Field definitions ─────────────────────────────────────────────────────────

function ssi10_single_fields() {
    return [
        'hero_background_image'    => 'Hero Background Image',
        'about_background_image'   => 'About Background Image',
        'artist_background_image'  => 'Artist Background Image',
        'oscar_artist_image'       => 'Oscar Artist Image',
        'george_artist_image'      => 'George Artist Image',
        'booking_background_image' => 'Booking Background Image',
        'join_background_image'    => 'Join Us Background Image',
        'gallery_background_image' => 'Gallery Background Image',
        'contact_background_image' => 'Contact Background Image',
        'credits_background_image' => 'Credits Background Image',
    ];
}

function ssi10_gallery_fields() {
    return [
        'about_us_images' => 'About Us Images',
        'gallery_images'  => 'Gallery Images',
    ];
}

// ── Admin menu ────────────────────────────────────────────────────────────────

add_action( 'admin_menu', function () {
    add_menu_page(
        'Site Images',
        'Site Images',
        'manage_options',
        'shear-site-images',
        'ssi10_render_page',
        'dashicons-format-image',
        80
    );
} );

// ── Enqueue WordPress Media Library ──────────────────────────────────────────

add_action( 'admin_enqueue_scripts', function ( $hook ) {
    // Enqueue on the plugin page. Both hook name variants are checked
    // because the exact string depends on whether another plugin claimed
    // the same slug first.
    if ( str_contains( $hook, 'shear-site-images' ) || isset( $_GET['page'] ) && $_GET['page'] === 'shear-site-images' ) {
        wp_enqueue_media();
        wp_enqueue_script( 'jquery' );
    }
} );

// ── Save ──────────────────────────────────────────────────────────────────────

add_action( 'admin_post_ssi10_save', function () {
    if ( ! current_user_can( 'manage_options' ) ) {
        wp_die( 'Unauthorised', 403 );
    }
    check_admin_referer( SSI10_NONCE_ACTION, SSI10_NONCE_NAME );

    $stored = get_option( SSI10_OPTION_KEY, [] );
    if ( ! is_array( $stored ) ) {
        $stored = [];
    }

    foreach ( ssi10_single_fields() as $key => $label ) {
        if ( isset( $_POST[ $key ] ) && $_POST[ $key ] !== '' ) {
            $id = absint( $_POST[ $key ] );
            $stored[ $key ] = $id > 0 ? $id : null;
        } else {
            $stored[ $key ] = null;
        }
    }

    foreach ( ssi10_gallery_fields() as $key => $label ) {
        if ( ! empty( $_POST[ $key ] ) && is_array( $_POST[ $key ] ) ) {
            $stored[ $key ] = array_values( array_filter( array_map( 'absint', $_POST[ $key ] ) ) );
        } else {
            $stored[ $key ] = [];
        }
    }

    update_option( SSI10_OPTION_KEY, $stored );

    wp_safe_redirect( add_query_arg(
        [ 'page' => 'shear-site-images', 'saved' => '1' ],
        admin_url( 'admin.php' )
    ) );
    exit;
} );

// ── Admin page HTML ───────────────────────────────────────────────────────────

function ssi10_render_page() {
    if ( ! current_user_can( 'manage_options' ) ) {
        wp_die( 'Unauthorised' );
    }

    $s     = get_option( SSI10_OPTION_KEY, [] );
    if ( ! is_array( $s ) ) $s = [];
    $saved = ! empty( $_GET['saved'] );
    ?>
    <div class="wrap" style="max-width:1060px">
        <h1 style="margin-bottom:6px">Site Images</h1>
        <p style="color:#555;margin-bottom:20px">
            Upload or replace images used on the live website.
            Click <strong>Save Site Images</strong> when done.
        </p>

        <?php if ( $saved ) : ?>
            <div class="notice notice-success is-dismissible"><p>Images saved successfully.</p></div>
        <?php endif; ?>

        <?php
        // ── UPLOAD DIAGNOSTICS ────────────────────────────────────────
        $upload_dir   = wp_upload_dir();
        $dir_ok       = is_writable( $upload_dir['basedir'] );
        $php_limit    = ini_get( 'upload_max_filesize' );
        $post_limit   = ini_get( 'post_max_size' );
        $mem_limit    = ini_get( 'memory_limit' );
        $wp_limit     = size_format( wp_max_upload_size() );
        $has_errors   = ! $dir_ok;
        ?>
        <details style="margin-bottom:20px;background:<?php echo $has_errors ? '#fff3cd' : '#f0f8f0'; ?>;border:1px solid <?php echo $has_errors ? '#ffc107' : '#c3e6cb'; ?>;border-radius:6px;padding:12px 16px">
            <summary style="cursor:pointer;font-weight:600;font-size:.9rem">
                <?php echo $has_errors ? '⚠️ Upload Diagnostics (issue detected)' : '✅ Upload Diagnostics (all OK)'; ?>
            </summary>
            <table style="margin-top:12px;border-collapse:collapse;width:100%;max-width:560px">
                <tr>
                    <td style="padding:4px 12px 4px 0;font-weight:600">Upload directory writable</td>
                    <td style="padding:4px 0"><?php echo $dir_ok ? '✅ Yes' : '❌ No — ' . esc_html( $upload_dir['basedir'] ) . ' is not writable'; ?></td>
                </tr>
                <tr>
                    <td style="padding:4px 12px 4px 0;font-weight:600">PHP upload_max_filesize</td>
                    <td style="padding:4px 0"><?php echo esc_html( $php_limit ); ?></td>
                </tr>
                <tr>
                    <td style="padding:4px 12px 4px 0;font-weight:600">PHP post_max_size</td>
                    <td style="padding:4px 0"><?php echo esc_html( $post_limit ); ?></td>
                </tr>
                <tr>
                    <td style="padding:4px 12px 4px 0;font-weight:600">PHP memory_limit</td>
                    <td style="padding:4px 0"><?php echo esc_html( $mem_limit ); ?></td>
                </tr>
                <tr>
                    <td style="padding:4px 12px 4px 0;font-weight:600">WordPress max upload size</td>
                    <td style="padding:4px 0"><?php echo esc_html( $wp_limit ); ?></td>
                </tr>
                <tr>
                    <td style="padding:4px 12px 4px 0;font-weight:600">Upload path</td>
                    <td style="padding:4px 0;word-break:break-all"><?php echo esc_html( $upload_dir['basedir'] ); ?></td>
                </tr>
            </table>
        </details>

        <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
            <?php wp_nonce_field( SSI10_NONCE_ACTION, SSI10_NONCE_NAME ); ?>
            <input type="hidden" name="action" value="ssi10_save">

            <!-- ── SINGLE IMAGES ─────────────────────────────────── -->
            <h2>Single Images</h2>
            <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(255px,1fr));gap:18px;margin-bottom:36px">
                <?php foreach ( ssi10_single_fields() as $key => $label ) :
                    $id    = ! empty( $s[ $key ] ) ? absint( $s[ $key ] ) : 0;
                    $thumb = $id ? wp_get_attachment_image_url( $id, 'thumbnail' ) : '';
                    ?>
                    <div id="ssi10-<?php echo esc_attr( $key ); ?>"
                         style="background:#fff;border:1px solid #ddd;border-radius:6px;padding:16px">

                        <label style="display:block;font-weight:600;margin-bottom:10px">
                            <?php echo esc_html( $label ); ?>
                        </label>

                        <input type="hidden"
                               name="<?php echo esc_attr( $key ); ?>"
                               value="<?php echo esc_attr( $id ?: '' ); ?>"
                               class="ssi10-id">

                        <div class="ssi10-preview" style="margin-bottom:10px;min-height:4px">
                            <?php if ( $thumb ) : ?>
                                <img src="<?php echo esc_url( $thumb ); ?>"
                                     style="max-width:100%;max-height:130px;border-radius:4px;display:block" alt="">
                            <?php endif; ?>
                        </div>

                        <div style="display:flex;gap:8px;flex-wrap:wrap">
                            <button type="button" class="button ssi10-pick"
                                    data-field="<?php echo esc_attr( $key ); ?>">
                                <?php echo $id ? 'Replace Image' : 'Upload / Select Image'; ?>
                            </button>
                            <button type="button" class="button ssi10-remove"
                                    data-field="<?php echo esc_attr( $key ); ?>"
                                    style="<?php echo $id ? '' : 'display:none'; ?>">
                                Remove
                            </button>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>

            <!-- ── GALLERY / MULTIPLE IMAGES ────────────────────── -->
            <h2>Gallery / Multiple Images</h2>
            <?php foreach ( ssi10_gallery_fields() as $key => $label ) :
                $ids = ( ! empty( $s[ $key ] ) && is_array( $s[ $key ] ) ) ? $s[ $key ] : [];
                ?>
                <div id="ssi10-g-<?php echo esc_attr( $key ); ?>"
                     style="background:#fff;border:1px solid #ddd;border-radius:6px;padding:20px;margin-bottom:20px">

                    <h3 style="margin:0 0 12px"><?php echo esc_html( $label ); ?></h3>

                    <div class="ssi10-gids">
                        <?php foreach ( $ids as $id ) : ?>
                            <input type="hidden"
                                   name="<?php echo esc_attr( $key ); ?>[]"
                                   value="<?php echo esc_attr( absint( $id ) ); ?>">
                        <?php endforeach; ?>
                    </div>

                    <div class="ssi10-gthumbs"
                         style="display:flex;flex-wrap:wrap;gap:10px;margin-bottom:14px">
                        <?php foreach ( $ids as $id ) :
                            $t = wp_get_attachment_image_url( absint( $id ), 'thumbnail' );
                            if ( ! $t ) continue;
                            ?>
                            <div class="ssi10-twrap"
                                 data-id="<?php echo esc_attr( absint( $id ) ); ?>"
                                 style="position:relative">
                                <img src="<?php echo esc_url( $t ); ?>"
                                     style="width:88px;height:88px;object-fit:cover;border-radius:4px;display:block" alt="">
                                <button type="button" class="ssi10-trm" title="Remove"
                                        style="position:absolute;top:2px;right:2px;background:rgba(0,0,0,.65);color:#fff;border:none;border-radius:50%;width:20px;height:20px;font-size:14px;line-height:18px;text-align:center;cursor:pointer;padding:0">
                                    &times;
                                </button>
                            </div>
                        <?php endforeach; ?>
                    </div>

                    <div style="display:flex;gap:8px;flex-wrap:wrap">
                        <button type="button" class="button ssi10-gadd"
                                data-field="<?php echo esc_attr( $key ); ?>">
                            Select / Add Images
                        </button>
                        <button type="button" class="button ssi10-gclear"
                                data-field="<?php echo esc_attr( $key ); ?>">
                            Clear All
                        </button>
                    </div>
                </div>
            <?php endforeach; ?>

            <p style="margin-top:24px">
                <button type="submit" class="button button-primary button-large">
                    Save Site Images
                </button>
            </p>
        </form>
    </div>

    <script>
    (function ($) {
        /* ── Single image ─────────────────────────────────────── */
        $(document).on('click', '.ssi10-pick', function () {
            var field = $(this).data('field');
            var card  = $('#ssi10-' + field);
            wp.media({
                title: 'Select Image',
                multiple: false,
                library: { type: 'image' },
                button: { text: 'Use This Image' }
            }).on('select', function () {
                var a = this.state().get('selection').first().toJSON();
                card.find('.ssi10-id').val(a.id);
                var t = (a.sizes && a.sizes.thumbnail) ? a.sizes.thumbnail.url : a.url;
                card.find('.ssi10-preview').html(
                    '<img src="' + t + '" style="max-width:100%;max-height:130px;border-radius:4px;display:block" alt="">'
                );
                card.find('.ssi10-pick').text('Replace Image');
                card.find('.ssi10-remove').show();
            }).open();
        });

        $(document).on('click', '.ssi10-remove', function () {
            var card = $('#ssi10-' + $(this).data('field'));
            card.find('.ssi10-id').val('');
            card.find('.ssi10-preview').html('');
            card.find('.ssi10-pick').text('Upload / Select Image');
            $(this).hide();
        });

        /* ── Gallery ──────────────────────────────────────────── */
        $(document).on('click', '.ssi10-gadd', function () {
            var field = $(this).data('field');
            var wrap  = $('#ssi10-g-' + field);
            wp.media({
                title: 'Select Images',
                multiple: 'add',
                library: { type: 'image' },
                button: { text: 'Add Selected Images' }
            }).on('select', function () {
                this.state().get('selection').each(function (attachment) {
                    var a  = attachment.toJSON();
                    if (wrap.find('.ssi10-gids input[value="' + a.id + '"]').length) return;
                    wrap.find('.ssi10-gids').append(
                        '<input type="hidden" name="' + field + '[]" value="' + a.id + '">'
                    );
                    var t = (a.sizes && a.sizes.thumbnail) ? a.sizes.thumbnail.url : a.url;
                    wrap.find('.ssi10-gthumbs').append(
                        '<div class="ssi10-twrap" data-id="' + a.id + '" style="position:relative">'
                        + '<img src="' + t + '" style="width:88px;height:88px;object-fit:cover;border-radius:4px;display:block" alt="">'
                        + '<button type="button" class="ssi10-trm" title="Remove" style="position:absolute;top:2px;right:2px;background:rgba(0,0,0,.65);color:#fff;border:none;border-radius:50%;width:20px;height:20px;font-size:14px;line-height:18px;text-align:center;cursor:pointer;padding:0">&times;</button>'
                        + '</div>'
                    );
                });
            }).open();
        });

        $(document).on('click', '.ssi10-trm', function () {
            var twrap = $(this).closest('.ssi10-twrap');
            var id    = twrap.data('id');
            var gwrap = twrap.closest('[id^="ssi10-g-"]');
            var field = gwrap.attr('id').replace('ssi10-g-', '');
            gwrap.find('.ssi10-gids input[value="' + id + '"]').remove();
            twrap.remove();
        });

        $(document).on('click', '.ssi10-gclear', function () {
            var wrap = $('#ssi10-g-' + $(this).data('field'));
            wrap.find('.ssi10-gids').html('');
            wrap.find('.ssi10-gthumbs').html('');
        });
    }(jQuery));
    </script>
    <?php
}

// ── REST endpoint ─────────────────────────────────────────────────────────────

add_action( 'rest_api_init', function () {
    register_rest_route( SSI10_REST_NS, '/' . SSI10_REST_ROUTE, [
        'methods'             => WP_REST_Server::READABLE,
        'callback'            => 'ssi10_rest_response',
        'permission_callback' => '__return_true',
    ] );
} );

function ssi10_rest_response() {
    $s = get_option( SSI10_OPTION_KEY, [] );
    if ( ! is_array( $s ) ) $s = [];

    $out = [];

    foreach ( ssi10_single_fields() as $key => $label ) {
        $id       = ! empty( $s[ $key ] ) ? absint( $s[ $key ] ) : 0;
        $url      = $id ? wp_get_attachment_url( $id ) : false;
        $out[ $key ] = ( $url && is_string( $url ) ) ? $url : null;
    }

    foreach ( ssi10_gallery_fields() as $key => $label ) {
        $ids  = ( ! empty( $s[ $key ] ) && is_array( $s[ $key ] ) ) ? $s[ $key ] : [];
        $urls = [];
        foreach ( $ids as $id ) {
            $url = wp_get_attachment_url( absint( $id ) );
            if ( $url ) $urls[] = $url;
        }
        $out[ $key ] = $urls;
    }

    return rest_ensure_response( $out );
}
